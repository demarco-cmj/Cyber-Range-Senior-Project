from cipher import compareCipher, check_answer, check_letter
##Global Variables:
answer = list()
alph = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

# The decode_cipher function takes in no arguments and returns answer - which should contain the correct cypher of the alphabet.
# The helper function check_answer(ans) takes in a list and returns either True or False if it was provided the same array as the cipher.
# Use the helper function check_answer(ans) to determine if you have the correct array before returning a list inside decode_cipher().
def decode_cipher():
    #TODO: Here try to find out what the cipher is.
    for x in range(26):
        for y in range(26):
            if (check_letter(alph[y], x)):
                answer.append(alph[y])

    #example of using check_answer():
    check_answer(answer)

    #return correct array for server to check
    return answer

# The get_password function needs to use your newly decoded cipher and return a string derrived from the known password "cyberadmin".
# This function will serve as how you "submit" your cracked password.
def test_password():
    #TODO: Here write code to convert your "cyberadmin" into the encrypted interpretation
    positions = [2, 24, 1, 4, 17, 0, 3, 12, 8, 13]
    password = ""
    for x in range(10):
        password += answer[positions[x]]

    return password

#PRINT KEY BOOL - Change to false to not print key with execution.
printKey = True

# Leave this alone, this is what will test your functions above
def main():
    pass
if __name__ == "__main__":
   compareCipher(printKey)
   main()
