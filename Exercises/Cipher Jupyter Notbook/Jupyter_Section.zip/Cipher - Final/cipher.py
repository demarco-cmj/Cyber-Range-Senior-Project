from random import seed
from random import randint
import time

#global Variables
cipher = list()
cipherPassword = ""

#Returns bool if the char provided is the same as the char in the cipher at the provided index
def check_letter(letter, index):
    if (letter == cipher[index]):
        return True
    return False

def check_answer(ans):
    if (ans == cipher):
        return True
    return False

def create(pKey):
    #Local Variables
    alph = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    password = "cyberadmin"
    global cipherPassword
    positions = [2, 24, 1, 4, 17, 0, 3, 12, 8, 13]

    seed(time.time() * 1000)
    randNum = randint(0, 1000)

    if(pKey):
        print("Cipher Key: \n")
    #Create cipher
    for x in range(26):
        cipher.append(chr(randNum % ord(alph[x]) % (122 - 96) + 97))
        if(pKey):
            print(alph[x], " = ", cipher[x])

    for x in range(10):
        cipherPassword += cipher[positions[x]]

def compareCipher(pKey):
    create(pKey)

    from cipher_script_ans import decode_cipher, test_password

    #Call student's script to validate contents of array and check runtime
    start = time.time()
    answer = decode_cipher()
    end = time.time() - start

    if(answer == cipher and end < 1):
        print("Cipher key correct! The script execution took ", end, "seconds. \n")
        if(test_password() == cipherPassword):
            print("The cipher key you created succeccfully changed \"cyberadmin\" to: \"" + cipherPassword + "\" --Password correct--")
        else:
            print("Password incorrect.")
    elif(answer == cipher and end >= 1):
        print("Your answer for the cipher was correct but your script took too long to execute.")
    else:
        print("Cipher answer provided is incorrect.")
